$folder = $PSScriptRoot
$settings = New-Object System.Xml.XmlReaderSettings
$settings.DtdProcessing = [System.Xml.DtdProcessing]::Parse
$settings.XmlResolver = New-Object System.Xml.XmlUrlResolver

$reader = [System.Xml.XmlReader]::Create("$folder\library.xml", $settings)
$xsl = New-Object System.Xml.Xsl.XslCompiledTransform
$xsl.Load("$folder\library.xsl")

$writer = [System.Xml.XmlWriter]::Create("$folder\library-output.html", $xsl.OutputSettings)
$xsl.Transform($reader, $null, $writer)

$writer.Close()
$reader.Close()
Start-Process "$folder\library-output.html"
