<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:template match="/">
<html>
<head>
    <title>Library Management</title>
    <style>
        body { font-family: Arial; margin: 30px; }
        h2 { color: darkblue; text-align: center; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 10px; }
        th { background-color: lightblue; }
        td { text-align: center; }
    </style>
</head>

<body>
    <h2>Library Management System</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Category</th>
            <th>Price</th>
        </tr>

        <xsl:for-each select="library/book">
            <tr>
                <td><xsl:value-of select="id"/></td>
                <td><xsl:value-of select="title"/></td>
                <td><xsl:value-of select="author"/></td>
                <td><xsl:value-of select="category"/></td>
                <td><xsl:value-of select="price"/></td>
            </tr>
        </xsl:for-each>

    </table>
</body>
</html>
</xsl:template>
</xsl:stylesheet>
