const express = require("express");
const { MongoClient, ObjectId } = require("mongodb");

const app = express();

app.use(express.json());
app.use(express.static("public"));

const MONGO_URI = "mongodb+srv://radhika:student12345@cluster1.0ohwm8h.mongodb.net/?appName=Cluster1";

async function startServer() {
    const client = new MongoClient(MONGO_URI);
    await client.connect();

    console.log("MongoDB connected");

    const db = client.db("mydb");
    const collection = db.collection("mycollection");

    // Display all elements
    app.get("/elements", async (req, res) => {
        const data = await collection.find().toArray();
        res.json(data);
    });

    // Add an element
    app.post("/elements", async (req, res) => {
        await collection.insertOne(req.body);
        res.json({ message: "Element added" });
    });

    // Delete an element
    app.delete("/elements/:id", async (req, res) => {
        await collection.deleteOne({
            _id: new ObjectId(req.params.id)
        });
        res.json({ message: "Element deleted" });
    });

    // Calculate average salary
    app.get("/average", async (req, res) => {
        const result = await collection.aggregate([
            {
                $group: {
                    _id: null,
                    average: { $avg: "$salary" }
                }
            }
        ]).toArray();

        res.json({
            average: result.length ? result[0].average : 0
        });
    });

    app.listen(3000, () => {
        console.log("Server running at http://localhost:3000");
    });
}

startServer().catch(console.error);
