<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:template match="/">
<html>
<body>
<h2>Application Details</h2>

<table border="1">
<tr>
<th>Field 1</th>
<th>Field 2</th>
<th>Field 3</th>
</tr>

<xsl:for-each select="records/record">
<tr>
<td><xsl:value-of select="field1"/></td>
<td><xsl:value-of select="field2"/></td>
<td><xsl:value-of select="field3"/></td>
</tr>
</xsl:for-each>

</table>
</body>
</html>
</xsl:template>

</xsl:stylesheet>
