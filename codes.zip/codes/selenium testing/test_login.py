from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()

try:
    driver.get("http://localhost:3000")

    # You enter the login details manually
    input("Enter username and password in Chrome, then press Enter here...")

    # Click Login
    driver.find_element(By.ID, "loginBtn").click()

    # Check the result
    result = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.ID, "result"))
    )

    print("Login result:", result.text)

    if result.text == "Login Successful":
        print("Test Passed")
    else:
        print("Invalid login test verified")

    input("Press Enter to close the browser...")

finally:
    driver.quit()
