const express = require("express");
const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

app.post("/login", (req, res) => {
    const { username, password } = req.body;

    if (username === "admin" && password === "1234") {
        res.send("<h2 id='result'>Login Successful</h2>");
    } else {
        res.send("<h2 id='result'>Invalid username or password</h2>");
    }
});

app.listen(3000, () => console.log("Server running on port 3000"));
