
const express = require("express");
const { MongoClient } = require("mongodb");

const app = express();
app.use(express.json());
app.use(express.static("public"));

const MONGO_URI = "mongodb://127.0.0.1:27017";

async function start() {
    const client = new MongoClient(MONGO_URI);
    await client.connect();

    const db = client.db("LeaveDB");
    const collection = db.collection("employees");

    // GET: Display employees
    app.get("/employees", async (req, res) => {
        res.json(await collection.find().toArray());
    });

    // POST: Add employee
    app.post("/employees", async (req, res) => {
        await collection.insertOne(req.body);
        res.json({ message: "Employee added" });
    });

    app.listen(3000, () => {
        console.log("Server running at http://localhost:3000");
    });
}

start().catch(console.error);
